# ilan.gov.tr Takip Botu
Bu bot ilanları Telegram üzerinden bildirir.
